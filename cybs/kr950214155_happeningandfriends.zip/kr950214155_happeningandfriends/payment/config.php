<?php

define('MERCHANT_ID', 'kr950214155');

// DF TEST: 1snn5n9w, LIVE: k8vif92e 
define('DF_ORG_ID', 'k8vif92e');

define('PROFILE_ID', '69D3DA0F-6959-4D3A-A1B2-D9D88DFBA141');
define('ACCESS_KEY', 'e4a5131693dd38878c1fefc97c9f2db8');
define('SECRET_KEY', '4d8c731b1d7840289f9431122e107c06299c684483b9442b97ff8ef771caa8f709b1d71bb1724ff885e3f835848ac9f663eb93ca13c5426fbd1155870437131b865120eb8326473892ba2ca55fef567509bdbc5db3c24f8f8137ac9772eb98006772301c518743a7bc7c65a1107c11da323b86eb04ef4cefb3c61e6b23988383');

// PAYMENT URL
define('CYBS_BASE_URL', 'https://secureacceptance.cybersource.com');

define('PAYMENT_URL', CYBS_BASE_URL . '/pay');
//define('PAYMENT_URL', './debug.php');

// EOF